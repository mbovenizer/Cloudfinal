-- inserting the data 

INSERT INTO statistics_table (Statistic, Year, Teachers, Countries, Unit, Value)
VALUES ('Ratio of students to teachers', 2023, 'Primary', 'Austria', 'Ratio', 12.2);
